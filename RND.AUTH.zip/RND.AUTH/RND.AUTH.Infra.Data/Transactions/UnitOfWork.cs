﻿using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Infra.Data.Transactions
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SqlContext _sqlContext;

        public UnitOfWork(SqlContext sqlContext)
        {
            _sqlContext = sqlContext;
        }

        public void Commit()
        {
            _sqlContext.SaveChanges();
        }

        public void Dispose()
        {
            _sqlContext.Dispose();
        }
    }
}