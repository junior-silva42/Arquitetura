﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Infra.Data.Transactions
{
    public interface IUnitOfWork : IDisposable
    {
        void Commit();
    }
}
