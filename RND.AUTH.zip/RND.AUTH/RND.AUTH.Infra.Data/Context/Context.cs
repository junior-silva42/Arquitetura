﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;

namespace RND.CBP.Infra.Data.Context
{
    public class SqlContext : DbContext
    {
        public SqlContext()
        {
        }

        public SqlContext(DbContextOptions<SqlContext> options) : base(options)
        {
        }

        //public DbSet<DataLiquidacao> DataLiquidacao { get; set; }

       


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                //IConfigurationRoot configuration = new ConfigurationBuilder().Build();
                //optionsBuilder.UseSqlServer("Server=172.25.14.102; Database=dbRendApiMesaCambio; Trusted_Connection=True; MultipleActiveResultSets=true");
            }
        }

        //protected override void OnModelCreating(ModuleBuilder modelBuilder)
        //{
        //    base.OnModelCreating(modelBuilder);
        //}

        public void DetachLocal<T>(T t, int entryId) where T : BaseEntity
        {
            var local = this.Set<T>().Local.FirstOrDefault(entry => entry.Id == entryId);

            if (local != null)
            {
                this.Entry(local).State = EntityState.Detached;
            }
            this.Entry(t).State = EntityState.Modified;
        }
    }
}