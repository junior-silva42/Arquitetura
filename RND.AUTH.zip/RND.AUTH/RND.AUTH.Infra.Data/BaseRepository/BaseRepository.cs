﻿using RND.CBP.Domain.Entities;
using RND.CBP.Domain.Interfaces.Repository;
using RND.CBP.Infra.Data.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RND.CBP.Infra.Data.BaseRepository
{
    public class BaseRepository<T> : IRepository<T> where T : BaseEntity
    {
        protected readonly SqlContext context;

        public BaseRepository(SqlContext _context)
        {
            context = _context;
        }

        public BaseRepository()
        {
        }

        public void Insert(T obj)
        {
            context.Set<T>().Add(obj);
            context.SaveChanges();
        }

        public void Update(T obj)
        {
            context.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            context.SaveChanges();
        }

        public void Delete(int id)
        {
            var t = SelectById(id);
            context.Set<T>().Remove(t);
            context.SaveChanges();
        }

        public List<T> SelectAll()
        {
            return context.Set<T>().ToList();
        }

        public T SelectById(int id)
        {

            return context.Set<T>().Where(c => c.Id == id).FirstOrDefault();

        }
    }
}