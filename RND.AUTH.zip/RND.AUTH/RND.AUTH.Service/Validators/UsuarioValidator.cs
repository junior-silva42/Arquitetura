﻿using FluentValidation;
using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Service.Validators
{
    public class UsuarioValidator : AbstractValidator<User>
    {

        public void UserValidator()
        {
            RuleFor(c => c)
                    .NotNull()
                    .OnAnyFailure(x =>
                    {
                        throw new ArgumentNullException("Can't found the object.");
                    });

            RuleFor(c => c.Cpf)
                .NotEmpty().WithMessage("Informar Cpf")
                .NotNull().WithMessage("Informar Cpf.");

            RuleFor(c => c.BirthDate)
                .NotEmpty().WithMessage("informar Data")
                .NotNull().WithMessage("informar Data");

            RuleFor(c => c.Name)
                .NotEmpty().WithMessage("Informar Nome")
                .NotNull().WithMessage("Informar Nome");
        }
    }
}