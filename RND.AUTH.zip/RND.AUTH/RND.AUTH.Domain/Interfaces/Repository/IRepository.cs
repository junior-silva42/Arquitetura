﻿using RND.CBP.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace RND.CBP.Domain.Interfaces.Repository
{
    public interface IRepository<T> where T : BaseEntity
    {
        void Insert(T obj);

        void Update(T obj);

        void Delete(int id);

        T SelectById(int id);

        List<T> SelectAll();
    }
}