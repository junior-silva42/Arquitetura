﻿using System;
using FluentValidation.Results;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Text;


namespace RND.CBP.Domain.Interfaces.Validator.Base
{
    public static class BaseValidator
{
    private static ConcurrentDictionary<Type, object> typeDefaults = new ConcurrentDictionary<Type, object>();

    public static object AddErrors(object obj, ValidationResult result)
    {
        var tipo = obj.GetType();
        var listErrors = new List<string>();

        PropertyInfo pIsvalid = tipo.GetProperty("IsValid");
        pIsvalid.SetValue(obj, result.IsValid);

        PropertyInfo pErros = tipo.GetProperty("Errors");
        result.Errors.ToList().ForEach(x => { listErrors.Add(x.ErrorMessage.ToString()); });
        pErros.SetValue(obj, listErrors);

        foreach (var item in result.Errors.ToList())
        {
            Type type = tipo.GetProperty(item.PropertyName).PropertyType;
            tipo.GetProperty(item.PropertyName).SetValue(obj, (type.IsValueType
                                                            ? typeDefaults.GetOrAdd(type, Activator.CreateInstance)
                                                            : String.Empty));
        }
        return obj;
    }
}

}
